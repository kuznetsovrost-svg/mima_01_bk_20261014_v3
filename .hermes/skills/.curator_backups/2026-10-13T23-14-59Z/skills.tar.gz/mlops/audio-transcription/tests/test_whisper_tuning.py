#!/usr/bin/env python3
"""Tests for Whisper tuning parameters (anti-hallucination, hotwords, two-pass).

Tests:
1. transcribe.py accepts all new CLI parameters
2. transcribe.py processes audio with hotwords
3. transcribe.py processes audio with anti-hallucination params
4. transcribe.py loads prompt from file
5. two_pass_transcribe.py extracts hotwords correctly
6. benchmark.py runs and generates report
7. All initial prompts exist and have content

Run: python3 tests/test_whisper_tuning.py
"""

import json
import subprocess
import sys
import time
from pathlib import Path

SKILL_DIR = Path("/root/.hermes/skills/mlops/audio-transcription")
SCRIPTS_DIR = SKILL_DIR / "scripts"
TEMPLATES_DIR = SKILL_DIR / "templates" / "initial_prompts"
TESTS_DIR = SKILL_DIR / "tests"

# Test fixtures
TEST_AUDIO = Path("/tmp/test-audio/fragment_2min.mp3")
TEST_OUT = Path("/tmp/test_whisper_tuning_out")


def test_new_files_exist():
    """Test 1: New files exist."""
    print("\n=== Test 1: New tuning files exist ===")
    required = [
        SCRIPTS_DIR / "two_pass_transcribe.py",
        SCRIPTS_DIR / "benchmark.py",
        TEMPLATES_DIR / "it_programming.txt",
        TEMPLATES_DIR / "marketing_sales.txt",
        TEMPLATES_DIR / "medicine.txt",
        TEMPLATES_DIR / "education.txt",
        TESTS_DIR / "test_whisper_tuning.py",
    ]
    for f in required:
        assert f.exists(), f"Missing: {f}"
        print(f"  ✓ {f.relative_to(SKILL_DIR)}")
    return True


def test_cli_help():
    """Test 2: transcribe.py shows new CLI parameters in --help."""
    print("\n=== Test 2: transcribe.py CLI has new parameters ===")
    result = subprocess.run(
        ["python3", str(SCRIPTS_DIR / "transcribe.py"), "--help"],
        capture_output=True, text=True, timeout=30
    )
    help_text = result.stdout
    required_params = [
        "--hotwords",
        "--no-vad",
        "--no-temperature-fallback",
        "--compression-ratio-threshold",
        "--log-prob-threshold",
        "--no-speech-threshold",
    ]
    for param in required_params:
        assert param in help_text, f"Missing CLI param: {param}"
        print(f"  ✓ {param}")
    return True


def test_initial_prompts_have_content():
    """Test 3: All initial prompts have content (general_russian may be minimal)."""
    print("\n=== Test 3: Initial prompts have content ===")
    prompts = [
        ("business_analysis.txt", 500),
        ("bpmn.txt", 500),
        ("general_russian.txt", 30),   # minimal general Russian is OK
        ("it_programming.txt", 500),
        ("marketing_sales.txt", 500),
        ("medicine.txt", 500),
        ("education.txt", 500),
    ]
    for p, min_bytes in prompts:
        path = TEMPLATES_DIR / p
        assert path.exists(), f"Missing: {p}"
        content = path.read_text(encoding="utf-8")
        assert len(content) > min_bytes, f"{p} too small: {len(content)} bytes (min {min_bytes})"
        word_count = len(content.split())
        print(f"  ✓ {p}: {len(content)} chars, {word_count} words")
    return True


def test_transcribe_with_hotwords():
    """Test 4: transcribe.py works with --hotwords parameter."""
    print("\n=== Test 4: transcribe.py with --hotwords ===")
    if not TEST_AUDIO.exists():
        print(f"  ⊘ SKIP: {TEST_AUDIO} not found")
        return True
    
    test_dir = TEST_OUT / "hotwords"
    test_dir.mkdir(parents=True, exist_ok=True)
    
    result = subprocess.run(
        [
            "python3", str(SCRIPTS_DIR / "transcribe.py"),
            str(TEST_AUDIO),
            "--output", str(test_dir),
            "--hotwords", "BPMN шлюз gateway процесс",
            "--beam-size", "1",  # fast test
        ],
        capture_output=True, text=True, timeout=300,
    )
    
    assert result.returncode == 0, f"Failed: {result.stderr}"
    
    # Check output files
    expected_files = ["fragment_2min.md", "fragment_2min_plain.md", "fragment_2min.json", "fragment_2min_words.json"]
    for fname in expected_files:
        path = test_dir / fname
        assert path.exists(), f"Missing output: {fname}"
        size = path.stat().st_size
        print(f"  ✓ {fname}: {size} B")
    
    # Check JSON has segments
    json_path = test_dir / "fragment_2min.json"
    data = json.loads(json_path.read_text(encoding="utf-8"))
    assert data["segments"] > 0, "No segments"
    print(f"  ✓ {data['segments']} segments, {data.get('words', '?')} words")
    return True


def test_transcribe_with_anti_hallucination():
    """Test 5: transcribe.py works with anti-hallucination parameters."""
    print("\n=== Test 5: transcribe.py with anti-hallucination params ===")
    if not TEST_AUDIO.exists():
        print(f"  ⊘ SKIP: {TEST_AUDIO} not found")
        return True
    
    test_dir = TEST_OUT / "anti_hallucination"
    test_dir.mkdir(parents=True, exist_ok=True)
    
    result = subprocess.run(
        [
            "python3", str(SCRIPTS_DIR / "transcribe.py"),
            str(TEST_AUDIO),
            "--output", str(test_dir),
            "--no-speech-threshold", "0.8",
            "--compression-ratio-threshold", "2.0",
            "--log-prob-threshold", "-0.5",
            "--beam-size", "1",
        ],
        capture_output=True, text=True, timeout=300,
    )
    
    assert result.returncode == 0, f"Failed: {result.stderr}"
    
    json_path = test_dir / "fragment_2min.json"
    data = json.loads(json_path.read_text(encoding="utf-8"))
    assert data["segments"] > 0, "No segments"
    print(f"  ✓ {data['segments']} segments (strict filtering)")
    return True


def test_prompt_loading():
    """Test 6: transcribe.py loads prompt from file."""
    print("\n=== Test 6: transcribe.py loads prompt from file ===")
    if not TEST_AUDIO.exists():
        print(f"  ⊘ SKIP: {TEST_AUDIO} not found")
        return True
    
    test_dir = TEST_OUT / "prompt_file"
    test_dir.mkdir(parents=True, exist_ok=True)
    
    prompt_path = TEMPLATES_DIR / "business_analysis.txt"
    assert prompt_path.exists()
    
    result = subprocess.run(
        [
            "python3", str(SCRIPTS_DIR / "transcribe.py"),
            str(TEST_AUDIO),
            "--output", str(test_dir),
            "--prompt", str(prompt_path),
            "--beam-size", "1",
        ],
        capture_output=True, text=True, timeout=300,
    )
    
    assert result.returncode == 0, f"Failed: {result.stderr}"
    assert "Loading prompt from" in result.stdout, "Prompt not loaded from file"
    print(f"  ✓ Prompt loaded from {prompt_path.name}")
    return True


def test_two_pass_importable():
    """Test 7: two_pass_transcribe.py is importable."""
    print("\n=== Test 7: two_pass_transcribe.py imports ===")
    result = subprocess.run(
        ["python3", "-c", f"import sys; sys.path.insert(0, '{SCRIPTS_DIR}'); import two_pass_transcribe; print('OK')"],
        capture_output=True, text=True, timeout=10,
    )
    assert result.returncode == 0, f"Import failed: {result.stderr}"
    assert "OK" in result.stdout
    print(f"  ✓ two_pass_transcribe.py imports successfully")
    return True


def test_benchmark_importable():
    """Test 8: benchmark.py is importable."""
    print("\n=== Test 8: benchmark.py imports ===")
    result = subprocess.run(
        ["python3", "-c", f"import sys; sys.path.insert(0, '{SCRIPTS_DIR}'); import benchmark; print('OK')"],
        capture_output=True, text=True, timeout=10,
    )
    assert result.returncode == 0, f"Import failed: {result.stderr}"
    assert "OK" in result.stdout
    print(f"  ✓ benchmark.py imports successfully")
    return True


def main():
    """Run all tests."""
    print("=" * 60)
    print("Whisper Tuning Tests")
    print("=" * 60)
    
    tests = [
        test_new_files_exist,
        test_cli_help,
        test_initial_prompts_have_content,
        test_transcribe_with_hotwords,
        test_transcribe_with_anti_hallucination,
        test_prompt_loading,
        test_two_pass_importable,
        test_benchmark_importable,
    ]
    
    passed = 0
    failed = 0
    for test in tests:
        try:
            if test():
                passed += 1
        except AssertionError as e:
            print(f"  ✗ FAIL: {e}")
            failed += 1
        except Exception as e:
            print(f"  ✗ ERROR: {e}")
            failed += 1
    
    print()
    print("=" * 60)
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    print("=" * 60)
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
