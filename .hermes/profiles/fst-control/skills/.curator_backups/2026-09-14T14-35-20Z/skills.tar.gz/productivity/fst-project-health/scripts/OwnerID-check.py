record = mcp__fst_pmpractice__get_entity_data(
    entityName="Project",
    data_id="4595"  # ProjectId
)

owner = record["properties"]["OwnerId"]
val = owner.get("value")
if not val:  # None или []
    result = "Нет"
    detail = "Роль Owner (Куратор) не назначена"
else:
    first = val[0] if isinstance(val, list) else val
    if isinstance(first, dict) and first.get("display"):
        result = "Да"
        detail = first["display"].strip()
    else:
        result = "Да"
        detail = f"id={first}"
