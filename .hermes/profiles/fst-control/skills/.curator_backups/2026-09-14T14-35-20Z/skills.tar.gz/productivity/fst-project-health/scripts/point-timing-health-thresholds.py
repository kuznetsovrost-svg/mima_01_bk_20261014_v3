# Пороги для оценки здоровья проекта по срокам по количеству критических замечаний по КТ
HEALTH_THRESHOLDS = {
    "sick": {
        "min_critical_count": 3,       # ≥ 3 критических → БОЛЕН
        "label": "БОЛЕН",
        "color": "КРАСНЫЙ",
    },
    "attention": {
        "min_critical_count": 1,       # 1 или 2 критических → ТРЕБУЕТ ВНИМАНИЯ
        "max_critical_count": 2,
        "label": "ТРЕБУЕТ ВНИМАНИЯ",
        "color": "ЖЕЛТЫЙ",
    },
    "healthy": {
        "max_critical_count": 0,       # 0 критических → ЗДОРОВ
        "label": "ЗДОРОВ",
        "color": "—",                  # без цвета
    },
}
