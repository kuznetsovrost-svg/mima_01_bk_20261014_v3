# Telegram — Field Notes

Concrete notes that complement the umbrella `messaging-gateway-setup`
skill. Read this when the user is specifically wiring up Telegram.

## Token & Auth

- Get the token from `@BotFather` in Telegram: `/newbot` → name →
  username (must end in `bot`) → copy token of form `123456:ABC-DEF…`.
- Hermes stores it as `TELEGRAM_BOT_TOKEN` in `~/.hermes/.env`.
  Format: `TELEGRAM_BOT_TOKEN=123456:ABC-DEF…` — no quotes, no spaces.
- Bot **must** be started by the user (`/start`) before it can DM them.
- A token that parses ≠ a token that the host can reach. See
  "Reachable vs Configured" below.

## Where Each Setting Lives

For Telegram specifically:

| Setting                     | Path in config.yaml                                       |
|-----------------------------|-----------------------------------------------------------|
| home chat id                | `gateway.platforms.telegram.home_chat_id: <int>`          |
| whitelist of users          | `gateway.platforms.telegram.allowed_users: [<id>, …]`     |
| whitelist of chats (groups) | top-level `telegram.allowed_chats: "<csv>"` (string!)     |
| pairing / approval          | `gateway.platforms.telegram.pairing: true`                |
| proxy (SOCKS5/HTTPS)        | `gateway.platforms.telegram.proxy: socks5://…`            |
| long-polling timeout        | `gateway.platforms.telegram.poll_timeout: 30`             |
| edit-message "typing"       | `display.platforms.telegram.streaming: true`              |
| reactions                   | top-level `telegram.reactions: false`                      |
| chat prompts                | top-level `telegram.channel_prompts: {}`                  |
| tools in this platform      | `platform_toolsets.telegram: [list]`                      |

`allowed_chats` is a **comma-separated string**, not a list. Common
mistake: writing it as a YAML list — works syntactically but the
matcher does a substring check, so the list form is silently ignored.

## "Configured" Does NOT Mean "Reachable"

Telegram's Bot API is at `https://api.telegram.org/`. Long-polling
opens persistent HTTPS connections. Common failure modes:

1. **IPv6-only DNS, no IPv4 route.** `getent hosts api.telegram.org`
   returns `2001:67c:4e8:f004::9`. If the host has no IPv6 egress, the
   connect times out. log shows repeating
   `Primary api.telegram.org connection failed ()`.
2. **ISP / datacenter blocks Telegram.** Same symptom, but every
   `curl https://api.telegram.org` also times out from the shell.
3. **Local firewall drops 149.154.160.0/20.** Telegram publishes
   fallback IPs in this range; if iptables/nftables blocks them,
   the adapter cycles through fallbacks and logs `Fallback IP … failed`.
4. **TLS interception / SNI mismatch** — uncommon, manifests as
   `SSL: CERTIFICATE_VERIFY_FAILED` in the log.

Quick triage:

```bash
curl -sS -m 8 -o /dev/null -w "v4 %{http_code} %{time_total}s\n" \
  -4 https://api.telegram.org/
curl -sS -m 8 -o /dev/null -w "v6 %{http_code} %{time_total}s\n" \
  -6 https://api.telegram.org/
curl -sS -m 8 https://149.154.166.110/     # one of Telegram's IPs
sudo iptables -L OUTPUT -n -v | head
ip route get 149.154.166.110
```

If egress is broken and you have a SOCKS5 proxy, set
`gateway.platforms.telegram.proxy: socks5://user:pass@host:1080`
and restart the gateway.

## Pairing / Approval Flow

- Default `pairing: true` — first time a new user DMs the bot, they
  are queued. Run `hermes pairing list` → `hermes pairing approve <id>`.
- For private/single-user bots, set `allowed_users: [<your_id>]`
  and skip pairing.
- Get your chat id: message the bot, then look in
  `~/.hermes/logs/gateway.log` for the update payload, or run
  `curl -s "https://api.telegram.org/bot<TOKEN>/getUpdates" | jq`.

## Long-Message Splitting

Telegram's hard cap is 4096 chars per message. Hermes's Telegram
adapter auto-splits above that. If you see `Bad Request: message is
too long` in the log, the streaming transport may have tried to edit
a message past the cap. Workarounds:
- `hermes config set streaming.enabled false`
- or shorten model outputs via prompt.

## Voice / Stickers / Inline

- Voice messages from users are auto-transcribed (see `stt.*` config).
- Stickers are received as `sticker` updates, ignored by default.
- Inline mode (`@yourbot query`) requires `inline_query` handler —
  not enabled in the default adapter.

## Restart Cheatsheet

```bash
hermes gateway restart                    # preferred
systemctl --user restart hermes-gateway   # if installed as service
hermes gateway status                     # confirm
tail -f ~/.hermes/logs/gateway.log        # watch
```
